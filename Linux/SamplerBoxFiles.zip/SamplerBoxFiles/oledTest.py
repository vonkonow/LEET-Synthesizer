from luma.core.interface.serial import spi
from luma.oled.device import ssd1306
from PIL import Image

serial = spi(port=0, device=0, gpio_DC=24, gpio_RST=25)
device = ssd1306(serial, rotate=0)

logo = Image.open('./Linux128x64.gif')
background = Image.new("RGB", device.size, "white")
background.paste(logo, (0, 0))
device.display(background.convert(device.mode))

import time
time.sleep(10)
